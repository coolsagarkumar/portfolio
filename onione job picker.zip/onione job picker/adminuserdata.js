window.onload = function() {
            // Retrieve the users name.
            var name = localStorage.getItem("name");
            var u_name = localStorage.getItem("u_name");
            var mail = localStorage.getItem("mail");
            var gender = localStorage.getItem("gender");
            var dob = localStorage.getItem("dob");
            var qualification = localStorage.getItem("qualification");
            var percentage = localStorage.getItem("percentage");
            var year = localStorage.getItem("year");
            var Specialization = localStorage.getItem("Specialization");
            var pwd = localStorage.getItem("pwd");
            var e_year = localStorage.getItem("e_year");
            var e_month = localStorage.getItem("e_month");
            var company = localStorage.getItem("company");
            var salary = localStorage.getItem("salary");
            var designation = localStorage.getItem("designation");

            if (name != "undefined" || name != "null") {

                document.getElementById('name').innerHTML = name;
                document.getElementById('u_name').innerHTML = u_name;
                document.getElementById('mail').innerHTML = mail;
                document.getElementById('Specialization').innerHTML = Specialization;
                document.getElementById('designation').innerHTML = designation;

            }
}

