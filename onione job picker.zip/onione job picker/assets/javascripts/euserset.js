window.onload = function() {

  // Check for LocalStorage support.
  if (localStorage) {

    // Add an event listener for form submissions
    document.getElementById('u_registration').addEventListener("submit", function() {
      // Get the value of the name field.
       var e_name = document.getElementById("e_name").value;
        var e_user = document.getElementById("e_user").value;
        var e_mail = document.getElementById("e_mail").value;
        var e_gender = document.getElementById("e_gender").value;
        var e_dob = document.getElementById("e_dob").value;
        var e_qualification = document.getElementById("e_qualification").value;
        var e_percentage = document.getElementById("e_percentage").value;
        var ex_year = document.getElementById("ex_year").value;
        var e_Specialization = document.getElementById("e_Specialization").value;
        var e_pwd = document.getElementById("e_pwd").value;
        var e_year = document.getElementById("e_year").value;
        var e_month = document.getElementById("e_month").value;
        var company = document.getElementById("company").value;
        var salary = document.getElementById("salary").value;
        var designation = document.getElementById("designation").value;
           
            
            /* save Registration filed in loval storage */
            
            localStorage.setItem("e_name", e_name);
            localStorage.setItem("e_user", e_user);
            localStorage.setItem("e_mail", e_mail);
            localStorage.setItem("e_gender", e_gender);
            localStorage.setItem("e_dob", e_dob);
            localStorage.setItem("e_qualification", e_qualification);
            localStorage.setItem("e_percentage", e_percentage);
            localStorage.setItem("ex_year", ex_year);
            localStorage.setItem("e_Specialization", e_Specialization);
            localStorage.setItem("e_pwd", e_pwd);
            localStorage.setItem("e_year", e_year);
            localStorage.setItem("e_month", e_month);
            localStorage.setItem("company", company);
            localStorage.setItem("salary", salary);
            localStorage.setItem("designation", designation);
                    

    });

  }
    
    

}

 