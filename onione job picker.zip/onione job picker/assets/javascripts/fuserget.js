window.onload = function() {
            // Retrieve the users name.
            var f_name = localStorage.getItem("f_name");
            var f_user = localStorage.getItem("f_user");
            var f_mail = localStorage.getItem("f_mail");
            var f_gender = localStorage.getItem("f_gender");
            var f_dob = localStorage.getItem("f_dob");
            var f_qualification = localStorage.getItem("f_qualification");
            var f_percentage = localStorage.getItem("f_percentage");
            var f_year = localStorage.getItem("f_year");
            var f_pwd = localStorage.getItem("f_pwd");
            var f_Specialization = localStorage.getItem("f_Specialization");
            

            if (name != "undefined" || name != "null") {

                document.getElementById('f_name').innerHTML = f_name;
                document.getElementById('f_user').innerHTML = f_user;
                document.getElementById('f_mail').innerHTML = f_mail;
                document.getElementById('f_gender').innerHTML = f_gender;
                document.getElementById('f_dob').innerHTML = f_dob;
                document.getElementById('f_qualification').innerHTML = f_qualification;
                document.getElementById('f_percentage').innerHTML = f_percentage;
                document.getElementById('f_year').innerHTML = f_year;
                document.getElementById('f_Specialization').innerHTML = f_Specialization;
                console.log(f_pwd);
                

            }
    
   


            // Retrieve the users name.
            var p_name = localStorage.getItem("p_name");
            var p_phonoe = localStorage.getItem("p_phonoe");
            var p_mail = localStorage.getItem("p_mail");
            var p_eligibility = localStorage.getItem("p_eligibility");
            var P_salary = localStorage.getItem("P_salary");
            var p_location = localStorage.getItem("p_location");
            var p_applydate = localStorage.getItem("p_applydate");
            var p_skills = localStorage.getItem("p_skills");
            var p_profile = localStorage.getItem("p_profile");
            

            if (name != "undefined" || name != "null") {

                document.getElementById('p_name').innerHTML = p_name;
                document.getElementById('p_phonoe').innerHTML = p_phonoe;
                document.getElementById('p_mail').innerHTML = p_mail;
                document.getElementById('p_eligibility').innerHTML = p_eligibility;
                document.getElementById('P_salary').innerHTML = P_salary;
                document.getElementById('p_location').innerHTML = p_location;
                document.getElementById('p_applydate').innerHTML = p_applydate;
                document.getElementById('p_skills').innerHTML = p_skills;
                document.getElementById('p_profile').innerHTML = p_profile;
                
            }
    
   


}

