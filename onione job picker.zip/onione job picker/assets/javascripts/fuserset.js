window.onload = function() {

  // Check for LocalStorage support.
  if (localStorage) {

    // Add an event listener for form submissions
    document.getElementById('fresher-register').addEventListener("submit", function() {
      // Get the value of the name field.
       var f_name = document.getElementById("f_name").value;
        var f_user = document.getElementById("f_user").value;
        var f_mail = document.getElementById("f_mail").value;
        var f_gender = document.getElementById("f_gender").value;
        var f_dob = document.getElementById("f_dob").value;
        var f_qualification = document.getElementById("f_qualification").value;
        var f_percentage = document.getElementById("f_percentage").value;
        var f_year = document.getElementById("f_year").value;
        var f_pwd = document.getElementById("f_pwd").value;
        var f_Specialization = document.getElementById("f_Specialization").value;
        
           
            
            /* save Registration filed in loval storage */
            
            localStorage.setItem("f_name", f_name);
            localStorage.setItem("f_user", f_user);
            localStorage.setItem("f_mail", f_mail);
            localStorage.setItem("f_gender", f_gender);
            localStorage.setItem("f_dob", f_dob);
            localStorage.setItem("f_qualification", f_qualification);
            localStorage.setItem("f_percentage", f_percentage);
            localStorage.setItem("f_year", f_year);
            localStorage.setItem("f_pwd", f_pwd);
            localStorage.setItem("f_Specialization", f_Specialization);
            
                    

    });

  }
    
    

}

 