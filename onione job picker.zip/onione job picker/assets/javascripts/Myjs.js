var msg = "You can't leave this field blank";

function namevalitate(){
    var str = document.getElementById("name").value;
    if (!str) {
        document.getElementById("msg").innerHTML = msg;
        /*document.getElementById("msg3").addClass("msg");*/
    }
 
}

function ValidateEmail() {
    var mail = document.getElementById("mail").value;
    if (!mail) {
        document.getElementById("msg3").innerHTML = msg;
        
    }
    else if (!(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/).test(mail)) {
            document.getElementById("msg3").innerHTML = "You have entered an invalid email address!";
        }
        else {
            document.getElementById("msg3").innerHTML = "";
        }
    }

function gendervalitate(){
var str = document.getElementById("gender").value;
    if (!str) {
        document.getElementById("msg4").innerHTML = msg;
        
    }    
}

/* date of birth validation */

function dob(){
    var str = document.getElementById("dob").value;
    if (!str) {
        document.getElementById("msg5").innerHTML = msg;
        
    }
    
}

/* user name validation */

function username(){
    var add = document.getElementById("u_name").value;
    if (!add) {
        document.getElementById("msg2").innerHTML = msg;
        
    }
}

/* user name validation */

function qualification(){
    var qualification = document.getElementById("qualification").value;
    if (!qualification) {
        document.getElementById("msg7").innerHTML = msg;
        
    }
}
/* strenth cheking validation */

function strenthcheck(){
    var pwd = document.getElementById("pwd");
    
	if(!pwd){
		document.getElementById("msg8").innerHTML = "you cant leave this filed black";
	}

}
   

/* full form validation */

function formvalidate(){
    var allmsg = document.getElementsByClassName("form-control");
for(i=0; i<allmsg.length; i++){
if (allmsg[i].value == ""){  
  alert("All fileds are mandotry...");
break;   
  }
}
}

function nextprocess(){
    var fresher = document.getElementById("fresher").value;
    var experience = document.getElementById("experience").value;
    
    if(fresher == experience){
        
    }
}

function logincheck(){
    var username = document.getElementById("u_name").value;
    var psw = document.getElementById("pwd").value;
    
    if(username == (localStorage.getItem(u_name))){
        alert("wellcome user...");
    
    }
}

 window.addEventListener("DOMContentLoaded", init);
        var a_name = "admin";
        var a_pwd = "admin";
        var u_name;
        var pwd;
        var l_name;
        var l_pwd;
        function init() {
        u_name = localStorage.getItem("u_name");
        pwd = localStorage.getItem("pwd");
        p_name = localStorage.getItem("p_name");
        p_password = localStorage.getItem("p_password");
        l_name = document.getElementById("l_name");
        l_pwd = document.getElementById("l_pwd");
    
        document.getElementById("submit_btn").addEventListener("click",login);
        }
             
        function login(){
             if(l_name.value == u_name && l_pwd.value == pwd){
                location.assign("file:///C:/ui%20batch/onione%20job%20picker/profile.html");
                 console.log("user function");
             }
            else if(l_name.value == a_name && l_pwd.value == a_pwd){
                location.assign("file:///C:/ui%20batch/onione%20job%20picker/admin-profile.html");
                 console.log("amdin function");
            }
            else if(l_name.value == p_name && l_pwd.value == p_password){
                location.assign("file:///C:/ui%20batch/onione%20job%20picker/recruiter_profile.html");
                 console.log("recruiter function");
            }
            
        else{
            alert("Uername or Password is incorrect!");
            console.log(u_name,pwd);
            console.log("l_name and l_pwd "+l_name+l_pwd);
        }      
            event.preventDefault();
    }



/* function resume(){
     var upload-files = document.getElementById("upload-files");
     
     if( !upload-files.value){
         alert("please Upload your Resume!");
     }
     else{
         alert("You have Successfully Uploaded!");
     }
 }*/
