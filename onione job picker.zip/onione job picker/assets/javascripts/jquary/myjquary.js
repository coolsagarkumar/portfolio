$(document).ready(function(){
    $("#f_data").hide();
    $("#e_data").hide();
    $("#process_show").hide();
    $("#search").hide();
    
/*    $("#hide").click(function(){
        $("#demo").hide();
    });*/
    
    $("#fresher").click(function(){
        $("#f_data").show();
        $("#e_data").hide();
        
    });
    
    $("#experience").click(function(){
        $("#e_data").show();
        $("#f_data").hide();
    });
    
    $("#post_prcess").click(function(){
        $('#post_prcess').hide();
        
        $("#process_show").show();
    });
    
    $("#post_prcess").click(function(){
        $('#post_prcess').hide();
        
        $("#process_show").show();
    });
    
    $(function() {
    // Input radio-group visual controls
    $('.radio-group label').on('click', function(){
        $(this).removeClass('not-active').siblings().addClass('not-active');
    });
        
});
    $("#searchjob").click(function(){
        $("#search").show();
        /*var skills = $("#skills").text(); 
        var location = $("#location").text(); 
        if(!skills.text())
            {
                alert("Pelase Filed Desired");
                
            }
        else if(!location.text()){
            alert("Pelase Filed Desired");
        }
        else{
            $("#search").show();
        }*/
        
        
    });
    
    $("#apply").click(function(){
        alert("you have succesfully apply for the job!");
        $("#button-hide").hide();
    })
    
    $("#fresher").click(function(){
        $("profile-hide").hide();
    })
    
    $("#logout").click(function(){
        alert("Do You want to Logout");
    })
    
    $("#resume").click(function(){
        if(!$("type=[file]")){
            alert("Please upload your file");
        }
    })
    
    $("#p_edit").click(function(){
        
            alert("Do you want to Edit profile");
        
    });
    
    $("#post_prcess").click(function(){
        
            $("#psot-job").text("Post Your job");
        
    });
    
    $("#delte-profile").click(function(){
        $("#profile-hide").hide();
        $("##delte-profile").hide();
        alert("profile is Deleting");
    });
    
    $("#p_delete").click(function(){
        $("#p-hide").hide();
        $("#p_delete").hide();
        alert("Job is Deleting");
        
    });
    
    $("#mytable #checkall").click(function () {
        if ($("#mytable #checkall").is(':checked')) {
            $("#mytable input[type=checkbox]").each(function () {
                $(this).prop("checked", true);
            });

        } else {
            $("#mytable input[type=checkbox]").each(function () {
                $(this).prop("checked", false);
            });
        }
    });
    
    $("#blanksearch").click(function(){
        alert("Please Login first...!");
    });
    
    
});

