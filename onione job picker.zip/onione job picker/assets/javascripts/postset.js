window.onload = function() {

  // Check for LocalStorage support.
  if (localStorage) {

    // Add an event listener for form submissions
    document.getElementById('post_job').addEventListener("submit", function() {
      // Get the value of the name field.
       var p_name = document.getElementById("p_name").value;
        var p_phonoe = document.getElementById("p_phonoe").value;
        var p_mail = document.getElementById("p_mail").value;
        var p_password = document.getElementById("p_password").value;
        var p_eligibility = document.getElementById("p_eligibility").value;
        var P_salary = document.getElementById("P_salary").value;
        var p_location = document.getElementById("p_location").value;
        var p_applydate = document.getElementById("p_applydate").value;
        var p_skills = document.getElementById("p_skills").value;
        var p_profile = document.getElementById("p_profile").value;
           
            
            /* save Registration filed in loval storage */
            
            localStorage.setItem("p_name", p_name);
            localStorage.setItem("p_phonoe", p_phonoe);
            localStorage.setItem("p_mail", p_mail);
            localStorage.setItem("p_password", p_password);
            localStorage.setItem("p_eligibility", p_eligibility);
            localStorage.setItem("P_salary", P_salary);
            localStorage.setItem("p_location", p_location);
            localStorage.setItem("p_applydate", p_applydate);
            localStorage.setItem("p_skills", p_skills);
            localStorage.setItem("p_profile", p_profile);
    });

  }

}

 