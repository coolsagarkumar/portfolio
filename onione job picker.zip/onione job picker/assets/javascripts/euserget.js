window.onload = function() {
            // Retrieve the users name.
            var e_name = localStorage.getItem("e_name");
            var e_user = localStorage.getItem("e_user");
            var e_mail = localStorage.getItem("e_mail");
            var e_gender = localStorage.getItem("e_gender");
            var e_dob = localStorage.getItem("e_dob");
            var e_qualification = localStorage.getItem("e_qualification");
            var e_percentage = localStorage.getItem("e_percentage");
            var ex_year = localStorage.getItem("ex_year");
            var Specialization = localStorage.getItem("Specialization");
            var e_pwd = localStorage.getItem("e_pwd");
            var e_year = localStorage.getItem("e_year");
            var e_month = localStorage.getItem("e_month");
            var company = localStorage.getItem("company");
            var salary = localStorage.getItem("salary");
            var designation = localStorage.getItem("designation");

            if (name != "undefined" || name != "null") {

                document.getElementById('e_name').innerHTML = e_name;
                document.getElementById('e_user').innerHTML = e_user;
                document.getElementById('e_mail').innerHTML = e_mail;
                document.getElementById('e_gender').innerHTML = e_gender;
                document.getElementById('e_dob').innerHTML = e_dob;
                document.getElementById('e_qualification').innerHTML = e_qualification;
                document.getElementById('w_year').innerHTML = e_year + " Year " + e_month + " Months";
                document.getElementById('e_gender').innerHTML = e_gender;
                document.getElementById('e_percentage').innerHTML = e_percentage;
                document.getElementById('ex_year').innerHTML = ex_year;
                document.getElementById('Specialization').innerHTML = Specialization;
                document.getElementById('salary').innerHTML = salary;
                document.getElementById('designation').innerHTML = designation;

            }
    
   


            // Retrieve the users name.
            var p_name = localStorage.getItem("p_name");
            var p_phonoe = localStorage.getItem("p_phonoe");
            var p_mail = localStorage.getItem("p_mail");
            var p_eligibility = localStorage.getItem("p_eligibility");
            var P_salary = localStorage.getItem("P_salary");
            var p_location = localStorage.getItem("p_location");
            var p_applydate = localStorage.getItem("p_applydate");
            var p_skills = localStorage.getItem("p_skills");
            var p_profile = localStorage.getItem("p_profile");
            

            if (name != "undefined" || name != "null") {

                document.getElementById('p_name').innerHTML = p_name;
                document.getElementById('p_phonoe').innerHTML = p_phonoe;
                document.getElementById('p_mail').innerHTML = p_mail;
                document.getElementById('p_eligibility').innerHTML = p_eligibility;
                document.getElementById('P_salary').innerHTML = P_salary;
                document.getElementById('p_location').innerHTML = p_location;
                document.getElementById('p_applydate').innerHTML = p_applydate;
                document.getElementById('p_skills').innerHTML = p_skills;
                document.getElementById('p_profile').innerHTML = p_profile;
                
            }
    
   


}

