window.onload = function(){
            // Retrieve the users name.
            var p_name = localStorage.getItem("p_name");
            var p_phonoe = localStorage.getItem("p_phonoe");
            var p_mail = localStorage.getItem("p_mail");
            var p_eligibility = localStorage.getItem("p_eligibility");
            var P_salary = localStorage.getItem("P_salary");
            var p_location = localStorage.getItem("p_location");
            var p_applydate = localStorage.getItem("p_applydate");
            var p_skills = localStorage.getItem("p_skills");
            var p_profile = localStorage.getItem("p_profile");
            

            if (name != "undefined" || name != "null") {

                document.getElementById('p_name').innerHTML = p_name;
                document.getElementById('p_phonoe').innerHTML = p_phonoe;
                document.getElementById('p_mail').innerHTML = p_mail;
                document.getElementById('p_eligibility').innerHTML = p_eligibility;
                document.getElementById('P_salary').innerHTML = P_salary;
                document.getElementById('p_location').innerHTML = p_location;
                document.getElementById('p_applydate').innerHTML = p_applydate;
                document.getElementById('p_skills').innerHTML = p_skills;
                document.getElementById('p_profile').innerHTML = p_profile;
                
            }
    
   


}
